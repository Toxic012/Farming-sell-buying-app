class Service {
  final String name;
  final String image;

  const Service({
    required this.name,
    required this.image,
  });
}
