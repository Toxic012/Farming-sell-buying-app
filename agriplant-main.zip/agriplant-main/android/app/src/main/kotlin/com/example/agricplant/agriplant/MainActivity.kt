package com.example.agricplant.agriplant

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
